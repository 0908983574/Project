#ifndef __LCD_PIC_H

#define _XTAL_FREQ  16000000
#include    <xc.h>

#define RS  RC0					//PIN for Control bits
#define RW  RC1
#define EN  RC2

#define RSDR    TRISC0			//PIN direction
#define RWDR    TRISC1
#define ENDR    TRISC2

#define DB7 RC7					//4 bits interface only 
#define DB6 RC6					//4 bits data PIN
#define DB5 RC5
#define DB4 RC4

#define DB7DR   TRISC7			//4bits PIN Direction
#define DB6DR   TRISC6
#define DB5DR   TRISC5
#define DB4DR   TRISC4


void LCD_PREDT(unsigned char data);			//Prepare data for PIN
void LCD_WriteIR(unsigned char data);		//Write Instruction to LCD
void LCD_WriteDT(unsigned char data);		//Write Data to LCD
void LCD_Init(void);						//Initialize LCD (first Instruction)
void LCD_WriteString(unsigned char* data);	//Write String to LCD, Last character '+'
void LCD_Set_Position (unsigned char hori, unsigned char vert);
#endif // !__LCD_PIC_H

