/*
 * File:   main.c
 * Author: Kim So
 *
 * Created on November 20, 2020, 6:33 AM
 * This program using measure Clock at PB1 Pin
 * This program have error about 4 percentage
 */

// PIC16F877A Configuration Bit Settings

// 'C' source line configuration statements

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
/* User include */
#include "LCD_PIC.h"
/* User define */
#define _FREQ_XTAL 16000000
/* User function prototype*/
void Initial (void);
void __interrupt() my_isr(void) ;
/* User global variable */
unsigned char start[20]= "FREQ AT RB0:+";
unsigned char times;
unsigned int count = 0;
/* User code */
/* User code begin*/
void __interrupt() my_isr(void)
{
    if ( INTF == 1)
    {
        count ++;
        INTF = 0;
    }
    if(TMR1IF == 1)
    {
        TMR1ON  =   0;
        TMR1    =   14500;  //Adjusted to higher accurate
        TMR1ON  =   1;
        times ++;
        if (times == 10)
        {
            times = 0;
            LCD_Set_Position(1,0);
            LCD_WriteDT(count/10000 + 0x30);
            LCD_WriteDT(count/1000%10 + 0x30);
            LCD_WriteDT(count/100%10 + 0x30);
            LCD_WriteDT(count/10%10 + 0x30);
            LCD_WriteDT(count%10 + 0x30);
            count = 0;
        }
        
        TMR1IF = 0;
    }
}
void Initial (void)
{
    TRISBbits.TRISB0 = 1;
    OPTION_REGbits.nRBPU = 0;
    OPTION_REGbits.INTEDG = 0;
    INTCONbits.GIE = 1;
    INTCONbits.INTE = 1;
    PEIE    = 1;
    TMR1IE  = 1;
    TMR1CS   = 0;
    T1CKPS1 = 1;
    T1CKPS0 = 1;
    TMR1ON  = 1;
    TMR1IF  =   0;
}
/* User code end*/
void main(void) {
    LCD_Init();
    Initial();
    LCD_WriteString(start);
    LCD_Set_Position(1,5);
    LCD_WriteString((unsigned char *) "Hz+");
    LCD_Set_Position(1,0);
    while(1)
    {

    }
}
